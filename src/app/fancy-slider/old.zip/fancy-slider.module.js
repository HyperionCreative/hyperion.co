(function () {
  'use strict';

  angular
    .module('specific.fancy-slider', []);
})();
